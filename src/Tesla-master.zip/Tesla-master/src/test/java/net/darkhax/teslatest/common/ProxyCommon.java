package net.darkhax.teslatest.common;

public class ProxyCommon {

    public void preInit () {

    }
}
