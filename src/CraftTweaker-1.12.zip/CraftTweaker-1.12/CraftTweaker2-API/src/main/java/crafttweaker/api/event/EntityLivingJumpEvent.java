package crafttweaker.api.event;

import crafttweaker.annotations.ZenRegister;
import stanhebben.zenscript.annotations.ZenClass;

@ZenRegister
@ZenClass("crafttweaker.event.EntityLivingJumpEvent")
public interface EntityLivingJumpEvent extends ILivingEvent {}
