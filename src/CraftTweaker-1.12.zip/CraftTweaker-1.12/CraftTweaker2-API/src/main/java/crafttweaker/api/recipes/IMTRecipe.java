package crafttweaker.api.recipes;

@Deprecated
public interface IMTRecipe {
    
    ICraftingRecipe getRecipe();
}
