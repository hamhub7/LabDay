package crafttweaker.api.data;

/**
 * @author Stan
 */
public class IllegalDataException extends RuntimeException {
    
    public IllegalDataException(String message) {
        super(message);
    }
}
