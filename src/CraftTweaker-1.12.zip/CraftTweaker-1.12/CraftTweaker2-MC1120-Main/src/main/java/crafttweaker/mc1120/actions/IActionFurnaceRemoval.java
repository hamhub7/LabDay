package crafttweaker.mc1120.actions;

import crafttweaker.IAction;

public interface IActionFurnaceRemoval extends IAction {}
