package com.blamejared.ctgui.api;

import net.minecraft.inventory.IInventory;

/**
 * Created by Jared.
 */
public class SlotRecipeOutput extends SlotRecipe {

    public SlotRecipeOutput(IInventory inventoryIn, int index, int xPosition, int yPosition) {
        super(inventoryIn, index, xPosition, yPosition);
    }
}
