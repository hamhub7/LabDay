package mezz.jei.startup;

import net.minecraftforge.fml.common.eventhandler.Event;

public class PlayerJoinedWorldEvent extends Event {
}
